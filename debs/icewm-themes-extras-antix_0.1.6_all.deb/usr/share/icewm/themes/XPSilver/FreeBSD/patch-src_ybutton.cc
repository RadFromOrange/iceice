--- src/ybutton.cc.orig	2004-11-07 13:49:19.926827944 -0600
+++ src/ybutton.cc	2004-11-07 13:49:30.113279368 -0600
@@ -103,8 +103,7 @@
         g.setColor(surface.color);
 
         if (wmLook == lookMetal) {
-            g.drawBorderM(x, y, w - 1, h - 1, !d);
-            d = 0; x += 2; y += 2; w -= 4; h -= 4;
+	    d=0;
         } else if (wmLook == lookGtk) {
             g.drawBorderG(x, y, w - 1, h - 1, !d);
             x += 1 + d; y += 1 + d; w -= 3; h -= 3;
@@ -114,7 +113,6 @@
         }
 
         paint(g, d, YRect(x, y, w, h));
-        paintFocus(g, YRect(x, y, w, h));
     }
 }
 
